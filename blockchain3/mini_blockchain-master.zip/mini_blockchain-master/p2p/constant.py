# coding: utf-8
K = 20 # bucket的大小
BITS = 128 # bucket中节点的位数
ALPHA = 3